// MechAI+ JavaScript Functions

// Global Variables
let flashlightOn = false;
let sosActive = false;
let currentLocation = null;

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    checkGeolocation();
});

// Initialize application
function initializeApp() {
    console.log('MechAI+ App Initialized');
    
    // Add fade-in animation to sections
    const sections = document.querySelectorAll('.section');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in-up');
            }
        });
    }, { threshold: 0.1 });
    
    sections.forEach(section => {
        observer.observe(section);
    });
    
    // Initialize tooltips if Bootstrap is available
    if (typeof bootstrap !== 'undefined') {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
}

// Setup event listeners
function setupEventListeners() {
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Add click effects to buttons
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            // Create ripple effect
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.classList.add('ripple');
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
}

// Navigation Functions
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Diagnosis Functions
function uploadPhoto() {
    // Simulate file upload
    showNotification('Opening camera for photo capture...', 'info');
    
    // Create file input element
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*';
    fileInput.capture = 'environment'; // Use rear camera on mobile
    
    fileInput.onchange = function(event) {
        const file = event.target.files[0];
        if (file) {
            processPhoto(file);
        }
    };
    
    fileInput.click();
}

function processPhoto(file) {
    showNotification('Processing photo...', 'info');
    
    // Simulate AI processing
    setTimeout(() => {
        const diagnoses = [
            'Battery terminals appear corroded. Clean with baking soda solution.',
            'Engine air filter looks dirty. Replace for better performance.',
            'Brake pads show signs of wear. Check thickness and replace if needed.',
            'Tyre pressure appears low. Inflate to recommended PSI.',
            'Oil level seems low. Check dipstick and add oil if necessary.'
        ];
        
        const randomDiagnosis = diagnoses[Math.floor(Math.random() * diagnoses.length)];
        displayDiagnosisResult(randomDiagnosis, 'photo');
        
        showNotification('Photo analysis complete!', 'success');
    }, 3000);
}

function recordVoice() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        showNotification('Voice recording not supported on this device', 'error');
        return;
    }
    
    showNotification('Tap to start recording...', 'info');
    
    // Simulate voice recording
    navigator.mediaDevices.getUserMedia({ audio: true })
        .then(function(stream) {
            startVoiceRecording(stream);
        })
        .catch(function(error) {
            console.error('Error accessing microphone:', error);
            showNotification('Microphone access denied', 'error');
            // Show fallback voice input
            showVoiceInputFallback();
        });
}

function startVoiceRecording(stream) {
    showNotification('Recording... Describe your vehicle problem', 'info');
    
    // Simulate recording for 5 seconds
    setTimeout(() => {
        stream.getTracks().forEach(track => track.stop());
        processVoiceInput();
    }, 5000);
}

function showVoiceInputFallback() {
    const userInput = prompt('Please describe your vehicle problem:');
    if (userInput && userInput.trim()) {
        processVoiceInput(userInput);
    }
}

function processVoiceInput(input = null) {
    showNotification('Processing voice input...', 'info');
    
    setTimeout(() => {
        const voiceDiagnoses = [
            'Based on the starting problem, check your battery connections and charge level.',
            'Engine knocking sounds suggest using higher octane fuel or checking timing.',
            'Grinding brakes indicate immediate pad replacement needed for safety.',
            'Unusual vibrations while driving often mean wheel balancing required.',
            'Overheating issues require checking coolant level and radiator condition.'
        ];
        
        const randomDiagnosis = voiceDiagnoses[Math.floor(Math.random() * voiceDiagnoses.length)];
        displayDiagnosisResult(randomDiagnosis, 'voice');
        
        showNotification('Voice analysis complete!', 'success');
    }, 3000);
}

function displayDiagnosisResult(diagnosis, method) {
    const resultsDiv = document.getElementById('diagnosisResults');
    const methodIcon = method === 'photo' ? '📸' : '🎤';
    
    resultsDiv.innerHTML = `
        <div class="alert alert-info border-cyan bg-dark-custom">
            <h5 class="text-cyan">${methodIcon} Diagnosis Result</h5>
            <p class="mb-3">${diagnosis}</p>
            <div class="d-flex gap-2 flex-wrap">
                <button class="btn btn-outline-primary btn-sm" onclick="speakText('${diagnosis}')">
                    <i class="bi bi-volume-up me-1"></i>Listen
                </button>
                <button class="btn btn-outline-primary btn-sm" onclick="showRelatedGuides()">
                    <i class="bi bi-book me-1"></i>Related Guides
                </button>
                <button class="btn btn-outline-primary btn-sm" onclick="saveResult('${diagnosis}')">
                    <i class="bi bi-bookmark me-1"></i>Save
                </button>
            </div>
        </div>
    `;
}

function speakText(text) {
    if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.8;
        utterance.pitch = 1;
        utterance.volume = 1;
        
        // Try to use a local language voice if available
        const voices = speechSynthesis.getVoices();
        const hindiVoice = voices.find(voice => voice.lang.startsWith('hi'));
        if (hindiVoice) {
            utterance.voice = hindiVoice;
        }
        
        speechSynthesis.speak(utterance);
        showNotification('Playing audio...', 'info');
    } else {
        showNotification('Speech synthesis not supported', 'error');
    }
}

function showRelatedGuides() {
    scrollToSection('guides');
    showNotification('Check out related repair guides below', 'info');
}

function saveResult(diagnosis) {
    // Save to localStorage (in a real app, this would be saved to a backend)
    const savedResults = JSON.parse(localStorage.getItem('mechai_diagnoses') || '[]');
    const newResult = {
        id: Date.now(),
        diagnosis: diagnosis,
        timestamp: new Date().toISOString(),
        date: new Date().toLocaleDateString()
    };
    
    savedResults.unshift(newResult);
    localStorage.setItem('mechai_diagnoses', JSON.stringify(savedResults.slice(0, 10))); // Keep last 10
    
    showNotification('Diagnosis saved successfully!', 'success');
}

// Guide Functions
function filterGuides() {
    const filter = document.getElementById('guideFilter').value;
    const cards = document.querySelectorAll('#guideGrid [data-category]');
    
    cards.forEach(card => {
        if (filter === 'all' || card.dataset.category === filter) {
            card.style.display = 'block';
            card.classList.add('fade-in-up');
        } else {
            card.style.display = 'none';
        }
    });
    
    showNotification(`Filtered guides: ${filter === 'all' ? 'All categories' : filter}`, 'info');
}

// SOS Functions
function activateSOS() {
    if (sosActive) {
        deactivateSOS();
        return;
    }
    
    sosActive = true;
    const sosButton = document.querySelector('.sos-button');
    
    showNotification('SOS ACTIVATED! Emergency services notified.', 'error');
    
    // Visual feedback
    sosButton.style.animation = 'pulse 0.5s infinite';
    sosButton.innerHTML = '<i class="bi bi-check-circle-fill"></i><span>ACTIVE</span>';
    
    // Get location and send SOS
    getCurrentLocation().then(location => {
        sendSOSAlert(location);
    });
    
    // Auto-deactivate after 30 seconds (safety measure)
    setTimeout(() => {
        if (sosActive) {
            deactivateSOS();
        }
    }, 30000);
}

function deactivateSOS() {
    sosActive = false;
    const sosButton = document.querySelector('.sos-button');
    
    sosButton.style.animation = 'none';
    sosButton.innerHTML = '<i class="bi bi-exclamation-triangle-fill"></i><span>SOS</span>';
    
    showNotification('SOS deactivated', 'info');
}

function sendSOSAlert(location) {
    // In a real app, this would send to emergency services
    console.log('SOS Alert sent with location:', location);
    
    // Simulate sending to emergency contacts
    const emergencyContacts = [
        { name: 'Emergency Services', number: '112' },
        { name: 'Family Contact', number: '+91-9876543210' },
        { name: 'Local Police', number: '100' }
    ];
    
    emergencyContacts.forEach(contact => {
        console.log(`Alert sent to ${contact.name}: ${contact.number}`);
    });
}

function toggleFlashlight() {
    flashlightOn = !flashlightOn;
    
    if (flashlightOn) {
        // Try to use device flashlight
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({ 
                video: { facingMode: 'environment' } 
            }).then(stream => {
                const track = stream.getVideoTracks()[0];
                if (track.getCapabilities && track.getCapabilities().torch) {
                    track.applyConstraints({ advanced: [{ torch: true }] });
                }
            }).catch(() => {
                // Fallback to screen flashlight
                showScreenFlashlight();
            });
        } else {
            showScreenFlashlight();
        }
        
        showNotification('Flashlight ON', 'success');
        document.querySelector('[onclick="toggleFlashlight()"]').innerHTML = 
            '<i class="bi bi-lightbulb-fill me-2"></i>Turn Off';
    } else {
        hideScreenFlashlight();
        showNotification('Flashlight OFF', 'info');
        document.querySelector('[onclick="toggleFlashlight()"]').innerHTML = 
            '<i class="bi bi-lightbulb me-2"></i>Flashlight';
    }
}

function showScreenFlashlight() {
    const flashlight = document.createElement('div');
    flashlight.id = 'screenFlashlight';
    flashlight.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: white;
        z-index: 9999;
        opacity: 0.9;
        pointer-events: none;
    `;
    document.body.appendChild(flashlight);
}

function hideScreenFlashlight() {
    const flashlight = document.getElementById('screenFlashlight');
    if (flashlight) {
        flashlight.remove();
    }
}

function shareLocation() {
    getCurrentLocation().then(location => {
        if (location) {
            const locationText = `My current location: https://maps.google.com/?q=${location.latitude},${location.longitude}`;
            
            if (navigator.share) {
                navigator.share({
                    title: 'MechAI+ Location Share',
                    text: 'I need help at this location:',
                    url: `https://maps.google.com/?q=${location.latitude},${location.longitude}`
                });
            } else {
                // Fallback: copy to clipboard
                navigator.clipboard.writeText(locationText).then(() => {
                    showNotification('Location copied to clipboard!', 'success');
                });
            }
        }
    });
}

function callEmergency() {
    const phoneNumber = '112'; // Emergency number for India
    if (confirm('Call emergency services (112)?')) {
        window.open(`tel:${phoneNumber}`);
        showNotification('Calling emergency services...', 'info');
    }
}

// Location Functions
function checkGeolocation() {
    if ('geolocation' in navigator) {
        navigator.geolocation.getCurrentPosition(
            position => {
                currentLocation = {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude
                };
            },
            error => {
                console.warn('Geolocation error:', error);
            }
        );
    }
}

function getCurrentLocation() {
    return new Promise((resolve, reject) => {
        if (currentLocation) {
            resolve(currentLocation);
            return;
        }
        
        if ('geolocation' in navigator) {
            navigator.geolocation.getCurrentPosition(
                position => {
                    const location = {
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude
                    };
                    currentLocation = location;
                    resolve(location);
                },
                error => {
                    console.error('Location error:', error);
                    reject(error);
                }
            );
        } else {
            reject(new Error('Geolocation not supported'));
        }
    });
}

// Contact Form Functions
function submitForm(event) {
    event.preventDefault();
    
    const name = document.getElementById('name').value;
    const phone = document.getElementById('phone').value;
    const message = document.getElementById('message').value;
    
    if (!name || !phone || !message) {
        showNotification('Please fill all fields', 'error');
        return;
    }
    
    // Simulate form submission
    showNotification('Submitting form...', 'info');
    
    setTimeout(() => {
        // Clear form
        document.getElementById('name').value = '';
        document.getElementById('phone').value = '';
        document.getElementById('message').value = '';
        
        showNotification('Message sent successfully! We will contact you soon.', 'success');
    }, 2000);
}

// Utility Functions
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type === 'error' ? 'danger' : type === 'success' ? 'success' : 'info'} position-fixed`;
    notification.style.cssText = `
        top: 20px;
        right: 20px;
        z-index: 10000;
        max-width: 300px;
        opacity: 0;
        transform: translateX(100%);
        transition: all 0.3s ease;
        border: 2px solid var(--primary-cyan);
        background: var(--black-bg);
        color: var(--white);
    `;
    
    const icon = type === 'error' ? '❌' : type === 'success' ? '✅' : 'ℹ️';
    notification.innerHTML = `${icon} ${message}`;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 4 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => notification.remove(), 300);
    }, 4000);
}

// Voice Commands (for accessibility)
function initializeVoiceCommands() {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'hi-IN'; // Hindi by default, can be changed
        
        recognition.onresult = function(event) {
            const command = event.results[0][0].transcript.toLowerCase();
            processVoiceCommand(command);
        };
        
        // Add voice command button to UI
        const voiceBtn = document.createElement('button');
        voiceBtn.className = 'btn btn-outline-primary position-fixed';
        voiceBtn.style.cssText = 'bottom: 20px; right: 20px; z-index: 1000; border-radius: 50%; width: 60px; height: 60px;';
        voiceBtn.innerHTML = '<i class="bi bi-mic"></i>';
        voiceBtn.onclick = () => {
            recognition.start();
            showNotification('Voice command: Say "diagnosis", "sos", "guides", etc.', 'info');
        };
        
        document.body.appendChild(voiceBtn);
    }
}

function processVoiceCommand(command) {
    if (command.includes('diagnosis') || command.includes('निदान')) {
        scrollToSection('diagnosis');
        showNotification('Opening diagnosis section', 'success');
    } else if (command.includes('sos') || command.includes('emergency') || command.includes('आपातकाल')) {
        scrollToSection('sos');
        showNotification('Opening emergency section', 'success');
    } else if (command.includes('guide') || command.includes('गाइड')) {
        scrollToSection('guides');
        showNotification('Opening repair guides', 'success');
    } else if (command.includes('home') || command.includes('होम')) {
        scrollToSection('home');
        showNotification('Going to home', 'success');
    } else {
        showNotification('Command not recognized. Try "diagnosis", "sos", or "guides"', 'error');
    }
}

// Offline Support Functions
function checkOnlineStatus() {
    const isOnline = navigator.onLine;
    const statusDiv = document.createElement('div');
    statusDiv.id = 'onlineStatus';
    statusDiv.className = `alert ${isOnline ? 'alert-success' : 'alert-warning'} position-fixed`;
    statusDiv.style.cssText = 'top: 80px; right: 20px; z-index: 1000; max-width: 250px;';
    statusDiv.innerHTML = `${isOnline ? '🟢' : '🔴'} ${isOnline ? 'Online' : 'Offline Mode'}`;
    
    // Remove existing status
    const existing = document.getElementById('onlineStatus');
    if (existing) existing.remove();
    
    document.body.appendChild(statusDiv);
    
    // Auto-hide after 3 seconds if online
    if (isOnline) {
        setTimeout(() => statusDiv.remove(), 3000);
    }
}

// Cache management for offline support
function cacheEssentialData() {
    const essentialData = {
        diagnoses: [
            'Check battery connections and charge level',
            'Inspect air filter and clean if dirty',
            'Verify oil level and quality',
            'Check tyre pressure and condition',
            'Examine brake pads and fluid'
        ],
        emergencyContacts: [
            { name: 'Emergency Services', number: '112' },
            { name: 'Police', number: '100' },
            { name: 'Fire Brigade', number: '101' }
        ],
        guides: [
            { title: 'Battery Jump Start', steps: ['Connect red cable to positive', 'Connect black cable to negative', 'Start donor vehicle', 'Start your vehicle'] },
            { title: 'Flat Tyre Change', steps: ['Apply handbrake', 'Loosen wheel bolts', 'Jack up vehicle', 'Remove flat tyre', 'Mount spare tyre'] }
        ]
    };
    
    localStorage.setItem('mechai_offline_data', JSON.stringify(essentialData));
}

// Initialize offline data on first load
function initializeOfflineSupport() {
    if (!localStorage.getItem('mechai_offline_data')) {
        cacheEssentialData();
    }
    
    checkOnlineStatus();
    
    // Listen for online/offline events
    window.addEventListener('online', checkOnlineStatus);
    window.addEventListener('offline', checkOnlineStatus);
}

// Data persistence functions
function saveDiagnosisHistory(diagnosis) {
    const history = JSON.parse(localStorage.getItem('mechai_history') || '[]');
    history.unshift({
        id: Date.now(),
        type: 'diagnosis',
        content: diagnosis,
        timestamp: new Date().toISOString()
    });
    localStorage.setItem('mechai_history', JSON.stringify(history.slice(0, 50))); // Keep last 50
}

function saveSOSLog(location) {
    const sosLogs = JSON.parse(localStorage.getItem('mechai_sos_logs') || '[]');
    sosLogs.unshift({
        id: Date.now(),
        location: location,
        timestamp: new Date().toISOString(),
        status: 'activated'
    });
    localStorage.setItem('mechai_sos_logs', JSON.stringify(sosLogs.slice(0, 20))); // Keep last 20
}

// Theme and Accessibility Functions
function adjustForAccessibility() {
    // High contrast mode detection
    if (window.matchMedia('(prefers-contrast: high)').matches) {
        document.body.classList.add('high-contrast');
    }
    
    // Reduced motion detection
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        document.body.classList.add('reduced-motion');
    }
    
    // Large text mode
    if (window.matchMedia('(prefers-text-size: large)').matches) {
        document.body.classList.add('large-text');
    }
}

// Keyboard navigation support
function setupKeyboardNavigation() {
    document.addEventListener('keydown', function(e) {
        // ESC key to close modals or stop SOS
        if (e.key === 'Escape') {
            if (sosActive) {
                deactivateSOS();
            }
        }
        
        // Space or Enter on focused buttons
        if ((e.key === ' ' || e.key === 'Enter') && e.target.classList.contains('diagnosis-tile')) {
            e.preventDefault();
            e.target.click();
        }
        
        // Number keys for quick navigation
        if (e.ctrlKey || e.metaKey) {
            switch(e.key) {
                case '1':
                    e.preventDefault();
                    scrollToSection('home');
                    break;
                case '2':
                    e.preventDefault();
                    scrollToSection('diagnosis');
                    break;
                case '3':
                    e.preventDefault();
                    scrollToSection('guides');
                    break;
                case '4':
                    e.preventDefault();
                    scrollToSection('sos');
                    break;
            }
        }
    });
}

// Performance optimization
function optimizePerformance() {
    // Lazy load images
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
    
    // Debounce scroll events
    let scrollTimer;
    window.addEventListener('scroll', () => {
        clearTimeout(scrollTimer);
        scrollTimer = setTimeout(() => {
            // Update active navigation item
            updateActiveNavigation();
        }, 100);
    });
}

function updateActiveNavigation() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    
    let currentSection = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (window.pageYOffset >= sectionTop - 200) {
            currentSection = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${currentSection}`) {
            link.classList.add('active');
        }
    });
}

// Error handling and logging
function setupErrorHandling() {
    window.addEventListener('error', function(e) {
        console.error('MechAI+ Error:', e.error);
        
        // Log error for debugging (in production, send to server)
        const errorLog = {
            message: e.message,
            filename: e.filename,
            lineno: e.lineno,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent
        };
        
        const errors = JSON.parse(localStorage.getItem('mechai_errors') || '[]');
        errors.unshift(errorLog);
        localStorage.setItem('mechai_errors', JSON.stringify(errors.slice(0, 10)));
        
        // Show user-friendly error message
        showNotification('Something went wrong. Please try again.', 'error');
    });
    
    // Handle unhandled promise rejections
    window.addEventListener('unhandledrejection', function(e) {
        console.error('Unhandled promise rejection:', e.reason);
        e.preventDefault();
    });
}

// Device-specific optimizations
function optimizeForDevice() {
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    const isTouch = 'ontouchstart' in window;
    
    if (isMobile) {
        document.body.classList.add('mobile-device');
        
        // Prevent zoom on input focus
        const inputs = document.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            input.addEventListener('focus', () => {
                document.querySelector('meta[name=viewport]').setAttribute('content', 
                    'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0');
            });
            
            input.addEventListener('blur', () => {
                document.querySelector('meta[name=viewport]').setAttribute('content', 
                    'width=device-width, initial-scale=1.0');
            });
        });
    }
    
    if (isTouch) {
        document.body.classList.add('touch-device');
        
        // Add touch feedback to buttons
        document.querySelectorAll('.btn, .diagnosis-tile, .guide-card').forEach(element => {
            element.addEventListener('touchstart', function() {
                this.classList.add('touch-active');
            });
            
            element.addEventListener('touchend', function() {
                setTimeout(() => this.classList.remove('touch-active'), 150);
            });
        });
    }
}

// Initialize all features when app starts
function initializeAllFeatures() {
    initializeApp();
    initializeOfflineSupport();
    initializeVoiceCommands();
    adjustForAccessibility();
    setupKeyboardNavigation();
    optimizePerformance();
    setupErrorHandling();
    optimizeForDevice();
    
    // Show welcome message
    setTimeout(() => {
        showNotification('Welcome to MechAI+! Your AI-powered vehicle assistant.', 'success');
    }, 1000);
}

// Call initialization when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeAllFeatures);
} else {
    initializeAllFeatures();
}